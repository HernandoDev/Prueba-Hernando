import { TestBed } from '@angular/core/testing';

import { VentasXPeriodoService } from './ventas-x-periodo.service';

describe('VentasXPeriodoService', () => {
  let service: VentasXPeriodoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VentasXPeriodoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
