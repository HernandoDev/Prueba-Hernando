import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpXhrBackend } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmpleadosService {
  private api = 'http://127.0.0.1:5000';
  constructor(private http: HttpClient,) {
  }
  obtenerEmpleados(){
    const ruta = `${this.api}/empleados`;
    return this.http.get(ruta);
  }
  obtenerEmpleadosMaxSalario(){
    const ruta = `${this.api}/empleados_max`;
    return this.http.get(ruta);
  }
  obtenerEmpleadosMinSalario(){
    const ruta = `${this.api}/empleados_min`;
    return this.http.get(ruta);
  }
  obtenerEmpleadoTop3Salario(){
    const ruta = `${this.api}/empleados_top_3`;
    return this.http.get(ruta);
  }
}
