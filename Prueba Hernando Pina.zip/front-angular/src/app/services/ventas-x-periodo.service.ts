import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpXhrBackend } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VentasXPeriodoService {
  private api = 'http://127.0.0.1:5000';

  constructor(private http: HttpClient,) {
    //
  }
  obtenerVentasXPeriodo(){
    const ruta = `${this.api}/ventas_x_periodo`;
    return this.http.get(ruta);
  }
  editarVentasXPeriodo(nuevoValor:number,id:number){
    const ruta = `${this.api}/ventas_x_periodo`;
    const body = {
      nuevoValor,
      id
    }
    return this.http.post(ruta, body);
  }
}
