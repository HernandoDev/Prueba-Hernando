import { Component, OnInit } from '@angular/core';
import { EmpleadosService } from "../../services/empleados.service";
import { VentasXPeriodoService } from "../../services/ventas-x-periodo.service";

import {MatTableModule} from '@angular/material/table';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  standalone: true,
  imports: [MatTableModule,HttpClientModule,CommonModule],
})
export class HomeComponent implements OnInit {
  displayedColumns: string[] = ['NumEmp', 'NumDept', 'NombreEmpleado', 'Salario'];
  displayedColumnsVentas: string[] = ['almacen_id', 'periodo', 'valor_vta'];
  subtotal = false;
  arraySubtotales: any[] = [];
  totalValorVta: number = 0;
  empleados:any;
  ventasXPeriodo:any;
  constructor(
    private empleadosService:EmpleadosService,
    private ventasXPeriodoService :VentasXPeriodoService
  ){}

  ngOnInit() {
    this.obtenerTodosEmpleados()
    this.obtenerVentasXPeriodo()

  }
  editarValorVTA(event:any,id:number){
    const nuevoValor = event.target.value;
    this.ventasXPeriodoService
    .editarVentasXPeriodo(nuevoValor,id)
    .subscribe((res: any) => {
      this.obtenerVentasXPeriodo()
      this.generararraySubtotales()
    });
  }
  obtenerVentasXPeriodo(){
    this.ventasXPeriodoService
    .obtenerVentasXPeriodo()
    .subscribe((res: any) => {
      this.ventasXPeriodo = res;
      this.generararraySubtotales();
    });
  }
  generararraySubtotales() {
    this.arraySubtotales = []
    const periodosSet = new Set<number>();
    this.ventasXPeriodo.forEach((item: { periodo: number; valor_vta: string | number; }) => {
      periodosSet.add(item.periodo);
      this.totalValorVta += +item.valor_vta;
    });

    periodosSet.forEach(periodo => {
      const valores = this.ventasXPeriodo.filter((item: { periodo: number; }) => item.periodo === periodo);
      const totalPeriodo = valores.reduce((total: number, val: { valor_vta: string | number; }) => total + +val.valor_vta, 0);
      const totalPorcentaje = (totalPeriodo / this.totalValorVta) * 100;

      const valoresConPorcentajes = valores.map((val: { valor_vta: string | number; }) => ({
        ...val,
        porcentaje_periodo: (+val.valor_vta / totalPeriodo) * 100,
        porcentaje_total: (+val.valor_vta / this.totalValorVta) * 100
      }));

      this.arraySubtotales.push({
        periodo: periodo,
        total: totalPeriodo,
        total_porcentaje: totalPorcentaje,
        valores: valoresConPorcentajes
      });
    });
  }
  obtenerTodosEmpleados(){
    this.empleadosService
    .obtenerEmpleados()
    .subscribe((res: any) => {
      this.empleados = res;
    });
  }
  obtenerEmpleadoMaxSalario(){
    this.empleadosService
    .obtenerEmpleadosMaxSalario()
    .subscribe((res: any) => {
      this.empleados = res;
    });
  }
  obtenerEmpleadoMinSalario(){
    this.empleadosService
    .obtenerEmpleadosMinSalario()
    .subscribe((res: any) => {
      this.empleados = res;
    });
  }
  obtenerEmpleadoTop3Salario(){
    this.empleadosService
    .obtenerEmpleadoTop3Salario()
    .subscribe((res: any) => {
      this.empleados = res;
    });
  }
}
