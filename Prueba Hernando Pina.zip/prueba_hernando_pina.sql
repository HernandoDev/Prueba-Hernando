-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.32 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para prueba_hernando_pina
CREATE DATABASE IF NOT EXISTS `prueba_hernando_pina` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `prueba_hernando_pina`;

-- Volcando estructura para tabla prueba_hernando_pina.departamento
CREATE TABLE IF NOT EXISTS `departamento` (
  `NumDept` int NOT NULL,
  `NombreDept` varchar(50) NOT NULL,
  PRIMARY KEY (`NumDept`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla prueba_hernando_pina.departamento: ~3 rows (aproximadamente)
INSERT INTO `departamento` (`NumDept`, `NombreDept`) VALUES
	(1, 'Departamento A'),
	(2, 'Departamento B'),
	(3, 'Departamento C');

-- Volcando estructura para tabla prueba_hernando_pina.empleados
CREATE TABLE IF NOT EXISTS `empleados` (
  `NumEmp` int NOT NULL,
  `NumDept` int NOT NULL,
  `NombreEmpleado` varchar(50) NOT NULL,
  `Salario` float NOT NULL,
  PRIMARY KEY (`NumEmp`),
  KEY `NumDept` (`NumDept`),
  CONSTRAINT `empleados_ibfk_1` FOREIGN KEY (`NumDept`) REFERENCES `departamento` (`NumDept`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla prueba_hernando_pina.empleados: ~10 rows (aproximadamente)
INSERT INTO `empleados` (`NumEmp`, `NumDept`, `NombreEmpleado`, `Salario`) VALUES
	(1, 1, 'Empleado 1', 2500),
	(2, 1, 'Empleado 2', 2800),
	(3, 2, 'Empleado 3', 2000),
	(4, 2, 'Empleado 4', 2200),
	(5, 3, 'Empleado 5', 2900),
	(6, 3, 'Empleado 6', 2700),
	(7, 1, 'Empleado 7', 2400),
	(8, 2, 'Empleado 8', 2800),
	(9, 3, 'Empleado 9', 2600),
	(10, 1, 'Empleado 10', 2300);

-- Volcando estructura para tabla prueba_hernando_pina.ventas_x_periodo
CREATE TABLE IF NOT EXISTS `ventas_x_periodo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `periodo` int DEFAULT NULL,
  `almacen_id` varchar(20) DEFAULT NULL,
  `valor_vta` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Volcando datos para la tabla prueba_hernando_pina.ventas_x_periodo: ~6 rows (aproximadamente)
INSERT INTO `ventas_x_periodo` (`id`, `periodo`, `almacen_id`, `valor_vta`) VALUES
	(1, 201101, 'ALM_10', 10.000),
	(2, 201101, 'ALM_20', 15.000),
	(3, 201101, 'ALM_30', 20.000),
	(4, 201102, 'ALM_10', 20.000),
	(5, 201102, 'ALM_20', 40.000),
	(6, 201102, 'ALM_10', 25.500);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
