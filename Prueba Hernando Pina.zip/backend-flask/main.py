from flask import Flask
from app.routes.empleados_routes import empleados_routes
from app.routes.departamentos_routes import departamentos_routes
from app.routes.ventas_x_periodo_routes import ventas_x_periodo_routes

from app.models.models import db, Empleados, Departamento
from flask_cors import CORS  

app = Flask(__name__)
conexion = 'mysql+mysqlconnector://root:root@localhost:3306/prueba_hernando_pina'
app.config['SQLALCHEMY_DATABASE_URI'] = conexion
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
CORS(app)

app.register_blueprint(empleados_routes)
app.register_blueprint(departamentos_routes)
app.register_blueprint(ventas_x_periodo_routes)

@app.route('/')
def saludo():
    return 'Servidor en funcionamiento, creado por Hernando Pina Henao'

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
