from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Departamento(db.Model):
    NumDept = db.Column(db.Integer, primary_key=True)
    NombreDept = db.Column(db.String(50), nullable=False)

class Empleados(db.Model):
    NumEmp = db.Column(db.Integer, primary_key=True)
    NumDept = db.Column(db.Integer, db.ForeignKey('departamento.NumDept'), nullable=False)
    NombreEmpleado = db.Column(db.String(50), nullable=False)
    Salario = db.Column(db.Float, nullable=False)
    departamento = db.relationship('Departamento', backref='empleados', lazy=True)
    
class VentasXPeriodo(db.Model):
    __tablename__ = 'ventas_x_periodo'
    
    id = db.Column(db.Integer, primary_key=True)
    periodo = db.Column(db.Integer)
    almacen_id = db.Column(db.String(20), primary_key=True)
    valor_vta = db.Column(db.DECIMAL(10, 3), nullable=False)