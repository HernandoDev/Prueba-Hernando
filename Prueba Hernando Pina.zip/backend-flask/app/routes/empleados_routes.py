from flask import Blueprint, request, jsonify
from app.models.models import db, Empleados

empleados_routes = Blueprint('empleados_routes', __name__)


@empleados_routes.route('/empleados', methods=['GET'])
def obtener_empleados():
    empleados = Empleados.query.all()
    empleados_json = [{'NumEmp': empleado.NumEmp, 'NumDept': empleado.NumDept, 'Departamento': empleado.departamento.NombreDept,'NombreEmpleado': empleado.NombreEmpleado, 'Salario': empleado.Salario} for empleado in empleados]
    return jsonify(empleados_json)

@empleados_routes.route('/empleados_max', methods=['GET'])
def obtener_empleados_max():
    empleado = Empleados.query.order_by(Empleados.Salario.desc()).first()
    empleados_json = [{'NumEmp': empleado.NumEmp, 'NumDept': empleado.NumDept,'Departamento': empleado.departamento.NombreDept, 'NombreEmpleado': empleado.NombreEmpleado, 'Salario': empleado.Salario} ]
    return jsonify(empleados_json)

@empleados_routes.route('/empleados_min', methods=['GET'])
def obtener_empleados_min():
    empleado = Empleados.query.order_by(Empleados.Salario.asc()).first()
    empleados_json = [{'NumEmp': empleado.NumEmp, 'NumDept': empleado.NumDept,'Departamento': empleado.departamento.NombreDept, 'NombreEmpleado': empleado.NombreEmpleado, 'Salario': empleado.Salario} ]
    return jsonify(empleados_json)

@empleados_routes.route('/empleados_top_3', methods=['GET'])
def obtener_empleados_top_3():
    empleados = Empleados.query.order_by(Empleados.Salario.desc()).limit(3).all()
    empleados_json = [{'NumEmp': empleado.NumEmp, 'NumDept': empleado.NumDept,'Departamento': empleado.departamento.NombreDept, 'NombreEmpleado': empleado.NombreEmpleado, 'Salario': empleado.Salario} for empleado in empleados]
    return jsonify(empleados_json)

@empleados_routes.route('/empleados', methods=['POST'])
def agregar_empleado():
    datos = request.json
    nuevo_empleado = Empleados(NumDept=datos['NumDept'], NombreEmpleado=datos['NombreEmpleado'], Salario=datos['Salario'])
    db.session.add(nuevo_empleado)
    db.session.commit()
    return jsonify({'mensaje': 'Empleado agregado correctamente'})
