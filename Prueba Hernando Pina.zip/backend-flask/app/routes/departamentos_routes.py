from flask import Blueprint, request, jsonify
from app.models.models import db, Departamento

departamentos_routes = Blueprint('departamentos_routes', __name__)

@departamentos_routes.route('/departamentos', methods=['GET'])
def obtener_departamentos():
    departamentos = Departamento.query.all()
    departamentos_json = [{'NumDept': departamento.NumDept, 'NombreDept': departamento.NombreDept} for departamento in departamentos]
    return jsonify(departamentos_json)

@departamentos_routes.route('/departamentos', methods=['POST'])
def agregar_departamento():
    datos = request.json
    nuevo_departamento = Departamento(NombreDept=datos['NombreDept'])
    db.session.add(nuevo_departamento)
    db.session.commit()
    return jsonify({'mensaje': 'Departamento agregado correctamente'})
