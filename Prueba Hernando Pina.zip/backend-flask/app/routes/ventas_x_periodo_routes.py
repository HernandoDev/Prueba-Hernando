from flask import Blueprint, request, jsonify
from app.models.models import db, VentasXPeriodo

ventas_x_periodo_routes = Blueprint('ventas_x_periodo_routes', __name__)

@ventas_x_periodo_routes.route('/ventas_x_periodo', methods=['GET'])
def obtener_ventas_x_periodo():
    ventas_x_periodos = VentasXPeriodo.query.all()
    ventas_x_periodos_json = [{'id': ventas_x_periodo.id, 'periodo': ventas_x_periodo.periodo,'almacen_id':ventas_x_periodo.almacen_id,'valor_vta':ventas_x_periodo.valor_vta} for ventas_x_periodo in ventas_x_periodos]
    return jsonify(ventas_x_periodos_json)

@ventas_x_periodo_routes.route('/ventas_x_periodo', methods=['POST'])
def editar_ventas_x_periodo():
    data = request.json
    venta_x_periodo_id = data.get('id')
    venta_x_periodo = VentasXPeriodo.query.filter(VentasXPeriodo.id == venta_x_periodo_id).first()
    if not venta_x_periodo:
        return jsonify({'error': 'Venta_x_periodo no encontrada'}), 404
    venta_x_periodo_valor = data.get('nuevoValor')
    venta_x_periodo.valor_vta = venta_x_periodo_valor
    db.session.commit()
    return jsonify({'mensaje': 'Venta_x_periodo actualizada correctamente'}), 200

