
# Prueba de Hernando Pina Henao

## Requisitos Previos

- Python 3.x instalado
- Virtualenv (opcional pero recomendado)

## Instalación

# Crea y activa un entorno virtual (opcional pero recomendado):
    python -m venv venv
    source venv/bin/activate  # En sistemas Unix
# o
    .\venv\Scripts\activate  # En sistemas Windows

# Instala las dependencias:
    pip install -r requirements.txt

# Instala la db prueba_hernando_pina.sql en tu entorno local o de preferencia 

# Inicia la aplicación Flask:
    python main.py

# La aplicación estará disponible en http://127.0.0.1:5000/.



# si tienes algun problema con el requirements puedes usar los siguientes comandos 

pip install Flask SQLAlchemy
pip install flask_sqlalchemy
pip install mysql-connector-python

# Si deseas instalarlo con Docker puedes emplear los siguientes comandos 
docker build -t backend-flask-prueba-hernando .
docker run -p 5000:5000 backend-flask-prueba-hernando



# Este es un proyecto basico de prueba para la candidatura de Quental Technologies realizada por Hernando Pina Henao 